import React, { useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { Box, Users, FileBox, LogOut, Settings, Plus, Download, Share2, Eye } from 'lucide-react';
import { ProjectStatus } from '../types';

// Mock Data
const PROJECTS = [
  { id: 'PRJ-001', name: 'Summer Menu Update', client: 'Bistro 55', status: ProjectStatus.Published, items: 12 },
  { id: 'PRJ-002', name: 'Fall Collection', client: 'Style Co', status: ProjectStatus.Processing, items: 45 },
  { id: 'PRJ-003', name: 'Ancient Egypt Exhibit', client: 'History Museum', status: ProjectStatus.QA, items: 8 },
];

const ASSETS = [
  { id: 'AST-101', name: 'Cheeseburger Deluxe', thumb: 'https://picsum.photos/seed/burger/100/100', status: 'Published' },
  { id: 'AST-102', name: 'Fries Basket', thumb: 'https://picsum.photos/seed/fries/100/100', status: 'Published' },
  { id: 'AST-103', name: 'Milkshake', thumb: 'https://picsum.photos/seed/shake/100/100', status: 'In Review' },
];

const Portal: React.FC<{ role: 'employee' | 'customer' }> = ({ role }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'projects' | 'customers' | 'assets'>('dashboard');

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col fixed h-full">
        <div className="p-6">
          <Link to="/" className="flex items-center gap-2 font-bold text-white text-lg">
            <Box className="w-6 h-6 text-brand-500" />
            <span>{role === 'employee' ? 'Console' : 'Portal'}</span>
          </Link>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'dashboard' ? 'bg-brand-600 text-white' : 'hover:bg-slate-800'}`}
          >
            <Box className="w-5 h-5" /> Dashboard
          </button>
          
          {role === 'employee' && (
            <button 
              onClick={() => setActiveTab('customers')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'customers' ? 'bg-brand-600 text-white' : 'hover:bg-slate-800'}`}
            >
              <Users className="w-5 h-5" /> Customers
            </button>
          )}

          <button 
            onClick={() => setActiveTab('projects')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'projects' ? 'bg-brand-600 text-white' : 'hover:bg-slate-800'}`}
          >
            <FileBox className="w-5 h-5" /> Projects
          </button>
        </nav>

        <div className="p-4 border-t border-slate-800">
           <button className="flex items-center gap-3 px-4 py-3 text-sm text-slate-400 hover:text-white w-full">
             <Settings className="w-5 h-5" /> Settings
           </button>
           <Link to="/" className="flex items-center gap-3 px-4 py-3 text-sm text-red-400 hover:text-red-300 w-full">
             <LogOut className="w-5 h-5" /> Sign Out
           </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 p-8">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
            </h1>
            <p className="text-slate-500">Welcome back, {role === 'employee' ? 'Admin' : 'Client'}.</p>
          </div>
          {role === 'employee' && (
             <button className="bg-brand-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-brand-700 flex items-center gap-2">
               <Plus className="w-4 h-4" /> New Project
             </button>
          )}
        </header>

        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <div className="text-slate-500 text-sm font-medium mb-2">Active Projects</div>
                <div className="text-3xl font-bold text-slate-900">12</div>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <div className="text-slate-500 text-sm font-medium mb-2">Assets in Review</div>
                <div className="text-3xl font-bold text-orange-600">5</div>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <div className="text-slate-500 text-sm font-medium mb-2">Published Assets</div>
                <div className="text-3xl font-bold text-green-600">148</div>
              </div>
            </div>

            {/* Recent Assets (Mock Library) */}
            <div>
              <h2 className="text-xl font-bold text-slate-900 mb-4">Recent Assets</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                 {ASSETS.map(asset => (
                   <div key={asset.id} className="bg-white rounded-lg border border-slate-200 overflow-hidden hover:shadow-md transition-shadow">
                     <div className="aspect-square bg-slate-100 relative">
                       <img src={asset.thumb} alt={asset.name} className="w-full h-full object-cover" />
                       <span className={`absolute top-2 right-2 px-2 py-1 text-xs font-bold rounded bg-white/90 ${asset.status === 'Published' ? 'text-green-600' : 'text-orange-600'}`}>
                         {asset.status}
                       </span>
                     </div>
                     <div className="p-4">
                       <h3 className="font-bold text-slate-900 text-sm mb-3">{asset.name}</h3>
                       <div className="flex justify-between">
                         <button className="p-2 text-slate-500 hover:bg-slate-50 rounded" title="View">
                           <Eye className="w-4 h-4" />
                         </button>
                         {role === 'customer' && (
                           <>
                             <button className="p-2 text-slate-500 hover:bg-slate-50 rounded" title="Download">
                               <Download className="w-4 h-4" />
                             </button>
                             <button className="p-2 text-slate-500 hover:bg-slate-50 rounded" title="Share">
                               <Share2 className="w-4 h-4" />
                             </button>
                           </>
                         )}
                       </div>
                     </div>
                   </div>
                 ))}
              </div>
            </div>
          </div>
        )}

        {/* Projects Table */}
        {(activeTab === 'projects' || activeTab === 'customers') && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="p-4 text-xs font-bold text-slate-500 uppercase">ID</th>
                  <th className="p-4 text-xs font-bold text-slate-500 uppercase">Project Name</th>
                  <th className="p-4 text-xs font-bold text-slate-500 uppercase">Client</th>
                  <th className="p-4 text-xs font-bold text-slate-500 uppercase">Status</th>
                  <th className="p-4 text-xs font-bold text-slate-500 uppercase">Items</th>
                  <th className="p-4 text-xs font-bold text-slate-500 uppercase">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {PROJECTS.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="p-4 text-sm text-slate-500 font-mono">{p.id}</td>
                    <td className="p-4 text-sm font-bold text-slate-900">{p.name}</td>
                    <td className="p-4 text-sm text-slate-600">{p.client}</td>
                    <td className="p-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        p.status === ProjectStatus.Published ? 'bg-green-100 text-green-800' :
                        p.status === ProjectStatus.Processing ? 'bg-blue-100 text-blue-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="p-4 text-sm text-slate-600">{p.items}</td>
                    <td className="p-4">
                      <button className="text-brand-600 hover:text-brand-800 text-sm font-bold">Manage</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
};

export default Portal;