export enum Industry {
  Restaurant = 'Restaurant',
  Museum = 'Museum',
  Ecommerce = 'Ecommerce',
  General = 'General'
}

export enum ProjectStatus {
  Intake = 'Intake',
  Capture = 'Capture',
  Processing = 'Processing',
  QA = 'QA',
  ReadyForReview = 'Ready for Review',
  Published = 'Published'
}

export interface NavItem {
  label: string;
  path: string;
}

export interface IndustryConfig {
  id: string;
  title: string;
  subtitle: string;
  heroImage: string;
  outcomes: string[];
  permissions: string[];
  demoImage: string;
}

export interface RequestFormState {
  industry: Industry | '';
  quantity_range: string;
  object_size_range: string;
  materials: string[];
  location_mode: 'on_site' | 'ship_in' | '';
  country: string;
  preferred_window: string;
  deliverables: string[];
  museum_access_control?: string;
  handling_sensitivity?: string;
  contact: {
    full_name: string;
    email: string;
    company: string;
  };
}